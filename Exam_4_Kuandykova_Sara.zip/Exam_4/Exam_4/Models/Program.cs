﻿
namespace Exam_4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            StartProgram start = new StartProgram();
            start.Start();
        }
    }
}
